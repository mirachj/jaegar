﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace forcalismasi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Manav manav;
        

        private void button1_Click(object sender, EventArgs e)
        {
            int muz, mandalina, portakal, kivi;
            muz= int.Parse(textBox1.Text);
            mandalina = int.Parse(textBox2.Text);
            portakal = int.Parse(textBox3.Text);
            kivi = int.Parse(textBox4.Text);

            try
            {
                manav = new Manav(muz, mandalina, portakal, kivi);
                MessageBox.Show("Stok Oluşturuldu!");
                stokguncelle();
                numericupdownmax();

            }
            catch (Exception)
            {

                MessageBox.Show("Lütfen Bilgileri Eksik Girmeyin!");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
         
          
        }
        public void numericupdownmax()
        {
            numericUpDown1.Maximum = manav.muz_adet();
            numericUpDown2.Maximum = manav.mandalina_adet();
            numericUpDown3.Maximum = manav.portakal_adet();
            numericUpDown4.Maximum = manav.kivi_adet();
        }
        public void stokguncelle()
        {
            labelkivi.Text = "STOK: " + manav.kivi_adet().ToString() + "kg";
            labelmand.Text = "STOK: " + manav.mandalina_adet().ToString() + "kg";
            labelport.Text = "STOK: " + manav.portakal_adet().ToString() + "kg";
            labelmuz.Text = "STOK:  " + manav.muz_adet().ToString() + "kg";
        }

        private void button2_Click(object sender, EventArgs e)
        {   
            
                manav.muz_satis(int.Parse(numericUpDown1.Value.ToString()));
                manav.mand_satis(int.Parse(numericUpDown2.Value.ToString()));
                manav.port_satis(int.Parse(numericUpDown3.Value.ToString()));
                manav.kivi_satis(int.Parse(numericUpDown4.Value.ToString()));
           
            MessageBox.Show("Satış Başarılı Stoklar Güncelleniyor...");
            stokguncelle();
            numericUpDown1.Value = 0;
            numericUpDown2.Value = 0;
            numericUpDown3.Value = 0;
            numericUpDown4.Value = 0;
            numericupdownmax();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Kasanızada toplam: "+manav.bakiye_tl()+"TL bulunmaktadır.");
        }
    }
}
