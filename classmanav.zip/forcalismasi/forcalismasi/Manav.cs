﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forcalismasi
{
    class Manav
    {
        int muz, mandalina, portakal, kivi;
        double bakiye;
        const double kivi_kgfiyat = 20.0;
        const double mandalina_kgfiyat = 15.0;
        const double portakal_kgfiyat = 17.0;
        const double muz_kgfiyat = 22.0;

        public Manav(int muzs,int mandalinas,int portakals,int kivis)
        {
            muz = muzs;
            mandalina = mandalinas;
            portakal = portakals;
            kivi = kivis;
            bakiye = 0;
        }
        public  void muz_satis(int sayi)
        {
           
            if (muz-sayi>0)
            {
                 muz = muz - sayi;
            bakiye += muz_kgfiyat;
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Stokta muz kalmamıştır!");
            }
                
            
        }
        public void mand_satis(int sayi)
        {
            if (mandalina - sayi > 0)
            {
                mandalina =mandalina-sayi;
                bakiye += mandalina_kgfiyat;
            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Stokta mandalina kalmamıştır!");
            }
           
        }
        public void port_satis(int sayi)
         {
                
            if (portakal - sayi > 0)
            {
                portakal=portakal-sayi;
                bakiye += portakal_kgfiyat;

            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Stokta portakal kalmamıştır!");
            }
        }
        public void kivi_satis(int sayi)
        {
            if (kivi - sayi > 0)
            {
                kivi = kivi - sayi;
            bakiye += kivi_kgfiyat;

            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Stokta kivi kalmamıştır!");
            }
            
        }
                           
       

        public double bakiye_tl()
        {
            return bakiye;
        }

        public int muz_adet()
        {
            return muz;
        }
        public int mandalina_adet()
        {
            return mandalina;
        }

        public int portakal_adet()
        {
            return portakal;
        }
        public int kivi_adet()
        {
            return kivi;
        }
    }
}
